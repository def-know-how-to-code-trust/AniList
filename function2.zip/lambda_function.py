import pymysql
import boto3
#congfig values
endpoint = 'dbuserinfo.cfqzogrx9hr6.us-east-1.rds.amazonaws.com'
username = 'admin'
password = '12121234'
database_name = 'User_Info'

#connection
connection = pymysql.connect(host=endpoint, user=username, passwd=password, db=database_name)
def lambda_handler(event, context):
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM userINFO")
    rows = cursor.fetchall()
    for row in rows:
        print("{0} {1} {2} {3}".format(row[0], row[1], row[2], row[3]))
